const global = require("../config.js")
const MENU_TEXT = 
`
╔═━━━✥◈✥━━━═╗
              MENU
╚═━━━✥◈✥━━━═╝

✦ User: vrz_
✦ Status: Online
✦ Uptime: ${formatUptime(process.uptime())}

〔 MAIN 〕
➤ ${global.PREFIX}menu
➤ ${global.PREFIX}menfess
`;

async function handleGeneral(ctx) {
    const { sock, msg, from, senderName, command } = ctx;

    const reply = (text) => sock.sendMessage(from, { text }, { quoted: msg });

    switch (command) {
        case `${global.PREFIX}menu`:
        case `${global.PREFIX}help`:
            await reply(MENU_TEXT);
            break;

        default:
            break;
    }
}

function formatUptime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}j ${m}m ${s}d`;
}

module.exports = { handleGeneral };
