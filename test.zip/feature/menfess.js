// handlers/menfess.js
const global = require("../config")

function normalizeNomor(raw) {
    if (!raw) return "";
    let n = String(raw).replace(/[^\d+]/g, "");
    if (n.startsWith("+")) n = n.slice(1);
    if (n.startsWith("0")) n = "62" + n.slice(1);
    return n.replace(/\D/g, "");
}

function getRawText(msg) {
    const m = msg?.message || {};
    return (
        m.conversation ||
        m.extendedTextMessage?.text ||
        m.imageMessage?.caption ||
        m.videoMessage?.caption ||
        ""
    );
}

async function handleMenfess(ctx) {
    const { sock, msg, from, command } = ctx;
    const reply = (t) => sock.sendMessage(from, { text: t }, { quoted: msg });

    if (command !== `${global.PREFIX}menfess`) return;

    const rawText = getRawText(msg).trim();
    const afterCmd = rawText.replace(/^!menfess\s+/i, "");

    if (!afterCmd || afterCmd.toLowerCase() === `${global.PREFIX}menfess`) {
        return reply(formatHelp());
    }

    const firstSpace = afterCmd.search(/\s+/);
    if (firstSpace === -1) return reply(formatHelp());

    const nomorRaw = afterCmd.slice(0, firstSpace);
    const pesan = afterCmd.slice(firstSpace + 1).trim();

    if (!nomorRaw || !pesan) return reply(formatHelp());

    const nomorBersih = normalizeNomor(nomorRaw);

    if (nomorBersih.length < 10 || nomorBersih.length > 15) {
        return reply(`❌ Nomor *${nomorRaw}* tidak valid.\nGunakan format: \`628123456789\``);
    }

    const botJid = (sock.user?.id || "").split(":")[0].split("@")[0];
    if (botJid && nomorBersih === botJid) {
        return reply("❌ Tidak bisa kirim menfess ke bot sendiri.");
    }

    let exists = false;
    try {
        const result = await sock.onWhatsApp(nomorBersih);
        exists = Array.isArray(result) ? !!result[0]?.exists : !!result?.exists;
    } catch (err) {
        console.error("[menfess] onWhatsApp error:", err);
        return reply("❌ Gagal cek nomor. Coba lagi nanti.");
    }

    if (!exists) {
        return reply(`❌ Nomor *${nomorBersih}* tidak terdaftar di WhatsApp.`);
    }

    const targetJid = `${nomorBersih}@s.whatsapp.net`;

    const timestamp = new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        hour12: false,
    });

    // 🔥 STRING UTAMA (SUDAH DIBENERIN)
    const pesanMenfess = `
╔══════════════════════╗
║   📨 *MENFESS*       ║
╚══════════════════════╝

${pesan}

──────────────────────
🕐 ${timestamp}
👤 _Anonim_

_Balas pesan ini untuk merespon (tetap anonim)._
`.trim();

    try {
        await sock.sendMessage(targetJid, { text: pesanMenfess });

        return reply(`✅ Menfess berhasil dikirim ke *${nomorBersih}* secara anonim!`);
    } catch (err) {
        console.error("[menfess] sendMessage error:", err);
        return reply(`❌ Gagal mengirim ke *${nomorBersih}*. Coba lagi nanti.`);
    }
}

function formatHelp() {
    return `
❌ *Format salah!*

Gunakan:
*${global.PREFIX}menfess [nomor] [pesan]*

Contoh:
${global.PREFIX}menfess 628123456789 Hei, aku suka sama kamu 😳
${global.PREFIX}menfess 08123456789 Halo apa kabar?
`.trim();
}

module.exports = { handleMenfess };